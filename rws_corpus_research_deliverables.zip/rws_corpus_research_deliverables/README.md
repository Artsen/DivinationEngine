# RWS Corpus Research Deliverables

This package was recreated from the completed Deep Research report after the original attachment upload failed.

## What is included

- Complete identity scaffold for all 78 Waite-Smith cards.
- One authoring JSON file per card.
- Source and tradition registries.
- Draft JSON Schemas.
- A current-importer compatibility template.
- Two example cards populated with short, source-faithful Waite excerpts:
  - The Fool
  - Ace of Cups

## Important limitation

The Deep Research run did **not** fully transcribe all 78 cards. The remaining 76 card files are curation templates.
They intentionally contain no AI-generated meanings or invented correspondences.

## Primary sources

Text:
- A. E. Waite, *The Pictorial Key to the Tarot*
- Scan-backed Wikisource witness:
  https://en.wikisource.org/wiki/The_Pictorial_Key_to_the_Tarot

Artwork:
- Original 1909 "Roses & Lilies" deck scan category on Wikimedia Commons:
  https://commons.wikimedia.org/wiki/Category:Rider-Waite_tarot_deck_(Roses_%26_Lilies)

Each released image should be verified at the individual Commons file page and accompanied by file-level rights/provenance metadata.

## Recommended next step

After DivinationEngine Milestone 1.1 is merged, adapt this authoring scaffold to the hardened stable-key/upsert importer, then complete the 78-card Waite transcription and file-level image verification.
