# Curation Checklist

For every card:

- [ ] Identity verified
- [ ] Image mapped to original 1909 Smith scan
- [ ] Individual image file rights checked
- [ ] Image dimensions recorded
- [ ] Image SHA-256 recorded after download
- [ ] Waite description/symbolism transcribed
- [ ] Waite upright/divinatory meaning transcribed
- [ ] Waite reversed meaning transcribed where present
- [ ] Minor Arcana additional meaning transcribed where present
- [ ] Exact text checked against scan
- [ ] Source locator recorded
- [ ] Stable interpretation keys assigned
- [ ] No correspondence invented
- [ ] Any later Golden Dawn/Crowley correspondence stored under separate provenance/tradition
